<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link rel="stylesheet" href="css/style.css" />
  <link rel="stylesheet" href="css/normalize.css" />
  <link
  rel="icon"
  href="./images/AJANS.png"
  type="image/x-icon"
  
/>
  <title>MMT AJANS</title>
</head>

<body>
  <header>
    <div class="logo"><img src="./images/AJANS.png" width="50px" height="50px" alt="">MMT AJANS</div>
    <div class="toggle"></div>
    <div class="navigation">
    <ul>
        <li><a href="index.php">Ana Sayfa</a></li>
        <li><a href="services.php">Servis</a></li>
        <li><a href="work.php">Çalışma Alanları</a></li>
        <li><a href="contact.php">İletişim</a></li>
      </ul>
      <div class="social-bar">
        <ul>
          <li>
            <a href="https://facebook.com">
              <img src="images/facebook.png" target="_blank" alt="" />
            </a>
          </li>
          <li>
            <a href="https://twitter.com">
              <img src="images/twitter.png" target="_blank" alt="" />
            </a>
          </li>
          <li>
            <a href="https://instagram.com">
              <img src="images/instagram.png" target="_blank" alt="" />
            </a>
          </li>
        </ul>
        <a href="mailto:you@email.com" class="email-icon">
          <img src="images/email.png" alt="" />
        </a>
      </div>
    </div>
  </header>


  <section class="home">
    <img src="images/home-img.jpg" class="home-img" alt="" />
    <div class="home-content">
      <h1>
        Başarmana yardımıcı olalım <br />
        Hedeflerine
      </h1>
      <p>
        Ajansımız, inovatif tasarımları ve etkili dijital stratejileri birleştirerek markanızı öne çıkarıyor. Deneyimli
        ekibimizle sizin için özel çözümler üreterek başarıya giden yolda yanınızdayız
      </p>
      <a href="work.php" class="btn">Hadi Başlayalım</a>
    </div>
  </section>

  <script src="js/script.js"></script>
</body>

</html>