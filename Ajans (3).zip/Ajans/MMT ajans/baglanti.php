<?php 
$host="localhost";
$kullanici="root";
$parola="";
$vt="ajans";

$baglanti= mysqli_connect($host, $kullanici, $parola, $vt);


?>